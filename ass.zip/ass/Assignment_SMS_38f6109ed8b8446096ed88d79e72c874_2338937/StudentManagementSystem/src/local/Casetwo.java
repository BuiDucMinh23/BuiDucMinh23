/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local;

import java.util.ArrayList;
import java.util.Scanner;
import static local.load.MARKS_FILE;
import static local.load.exercises;
import static local.load.marks;
import static local.load.students;
import static local.load.subjects;
import static local.save.saveFile;

/**
 *
 * @author Minh
 */
public class Casetwo {
    
    static void Lts(){
        System.err.println("List of students:");
        System.err.println("ID"+"\t\t"+"Name");
        for (String[] fields : students) {
            System.out.println(fields[0] + "\t\t" + fields[1]);
        }
    }
    static void Los(){
        System.err.println("List of subjects:");
        System.err.println("ID"+"\t\t"+"Name");
        for (String[] fields : subjects) {
            System.out.println(fields[0] + "\t\t" + fields[1]);
        }
    }
    static void enterMarks(Scanner scanner){
        Lts();
        String StudentID;
        boolean validSubject = false;
        do {
            System.out.print("Enter Student ID in the list: ");

            StudentID = scanner.nextLine().trim();
            for (String[] fields : marks) {
                if (fields[0].equals(StudentID)) {
                    validSubject = true;
                    break;
                }
            }
            if (!validSubject) {
                System.out.println("Invalid Student ID. Please try again.");
            }
        } while (!validSubject);
        Los();
        String subjectID;
        boolean validSubjec = false;
        do {
            System.out.print("Enter subject ID in the list: ");

            subjectID = scanner.nextLine().trim();
            for (String[] fields : marks) {
                if (fields[0].equals(StudentID)&&fields[1].equals(subjectID)) {
                    validSubjec = true;
                    break;
                }
            }
            if (!validSubjec) {
                System.out.println("Invalid subject ID. Please try again.");
            }
        } while (!validSubjec);
        System.err.println("List of marks of "+ subjectID +" for "+StudentID+" :");
        System.err.println("Exercise              Percentage   Marks");
        double d=0.0;
        for (String[] fields : marks) {
            int c=0;
              if (fields[0].equals(StudentID)&&fields[1].equals(subjectID)) {
                       for(String[] a:exercises){  
                          
                           if(a[1].equals(fields[2])){
                              System.err.println(fields[2]+"\t\t\t"+a[2] +"\t"+fields[3]);
                              double num = Double.parseDouble(a[2])*Double.parseDouble(fields[3])/100;
                              d+=num;
                              break;
                           }                       
                       }
                }
            }
        System.err.println("total"+"\t\t\t"+(double) Math.round(d*100)/100);
        String[] exercise = new String[4];
        
        
        
    String labID;
        boolean v = false;
        do {
            System.out.print("Enter exercise in the list: ");

            labID = scanner.nextLine().trim();
            for (String[] fields : exercises) {
                if (fields[1].equals(labID)) {
                    v = true;
                    break;
                }
            }
            
        } while (!v);    
        double za;
        do{
            System.err.print("Enter marks:");
            za=scanner.nextDouble();
        }while(1>za||za>10);
        exercise[0]=StudentID;
        exercise[1]=subjectID;
        exercise[2]=labID;
        exercise[3]=Double.toString(za);
        
        marks.add(exercise);
        for(String[] s:marks){
            if(s[0].equals(StudentID)&&s[1].equals(subjectID)&&s[2].equals(labID)){
                marks.remove(s);
            break;            }
            
        }
        saveFile(MARKS_FILE, marks);
        System.err.println("List of marks of "+ subjectID +" for "+StudentID+" :");
        System.err.println("Exercise              Percentage   Marks");
         for (String[] fields : marks) {
            int c=0;
              if (fields[0].equals(StudentID)&&fields[1].equals(subjectID)) {
                       for(String[] a:exercises){  
                          
                           if(a[1].equals(fields[2])){
                              System.err.println(fields[2]+"\t\t\t"+a[2] +"\t"+fields[3]);
                              double num = Double.parseDouble(a[2])*Double.parseDouble(fields[3])/100;
                              d+=num;
                              break;
                           }                       
                       }
                }
            }
        System.err.println("total"+"\t\t\t"+(double) Math.round(d*100)/100);
    }
}
