package local;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Minh
 */
public class Main {


    public static void main(String[] args){
        Caseone m=new Caseone();
        Casetwo ams=new Casetwo();
        load n=new load();
        n.loadData();
        Scanner scanner = new Scanner(System.in);
        int choice = 0;
        do {
            
            System.out.println("Assignment: SE1769, Group 2");
            System.out.println("MENU");
            System.out.println("1. Add a new exercise for the given subject.");
            System.out.println("2. Enter an exercise's marks of the given subject for a student.");
            System.out.println("3. Exit");
            System.out.print("Please enter 1, 2, or 3: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    
                    m.addExercise(scanner);
                    break;
                case 2:
                    ams.enterMarks(scanner);
                    break;
                case 3:
                    break;
                default:
                    System.out.println("Invalid choice. Please enter 1, 2, or 3.");
                    break;
            }
        } while (choice != 3);
        
        scanner.close();
    }
    
    
    
    
    
    
    
    
    
    
}
