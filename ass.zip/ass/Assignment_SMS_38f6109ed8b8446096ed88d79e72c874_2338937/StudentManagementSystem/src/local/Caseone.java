/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local;

import java.util.Scanner;
import static local.load.EXERCISES_FILE;
import static local.load.exercises;
import static local.load.subjects;
import static local.save.saveFile;

/**
 *
 * @author Minh
 */
public class Caseone {
    private static void takeTotal(Scanner scanner, String subjectID) {
        double count = 0.0;
        for (String[] fields : exercises) {
            if (fields[0].equalsIgnoreCase(subjectID)) {
                System.out.println(fields[1] + "\t\t" + fields[2]);
            }
        }

    }

    private static void takeTotal2(Scanner scanner, String subjectID) {
        double count = 0.0;
        for (String[] fields : exercises) {
            if (fields[0].equalsIgnoreCase(subjectID)) {
                double num = Double.parseDouble(fields[2]);
                count += num;
            }
        }
        System.err.println("=========================");
        System.err.println("Total" + "\t\t" + count);
    }

    static void addExercise(Scanner scanner) {
        System.out.println("List of subjects:");
        System.out.println("ID\tName");
        for (String[] fields : subjects) {
            System.out.println(fields[0] + "\t\t" + fields[1]);
        }
        // Prompt user to enter subject ID
        String subjectID;
        boolean validSubject = false;
        do {
            System.out.print("Enter subject ID in the list: ");

            subjectID = scanner.nextLine().trim();
            for (String[] fields : subjects) {
                if (fields[0].equals(subjectID)) {
                    validSubject = true;
                    break;
                }
            }
            if (!validSubject) {
                System.out.println("Invalid subject ID. Please try again.");
            }
        } while (!validSubject);
        // Prompt user to enter exercise name
        takeTotal(scanner, subjectID);
        takeTotal2(scanner, subjectID);
        String exerciseName;
        double percentage;
        do {
            System.err.print("Enter exercise name (not empty):");
            exerciseName = scanner.nextLine();
        } while (exerciseName.isEmpty());
        do {
            System.err.print("Enter percentage (1 – 96.25):");
            percentage = scanner.nextDouble();
        } while (percentage < 1 || percentage > 96.25);
        // Create a new exercise record
        String[] exercise = new String[3];
        exercise[0] = subjectID;
        exercise[1] = exerciseName;
        exercise[2] = Double.toString(percentage);
        exercises.add(exercise);
        saveFile(EXERCISES_FILE, exercises);
        takeTotal(scanner, subjectID);
        takeTotal2(scanner, subjectID);
        System.out.println("Exercise added successfully.");
    }
}
