/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package local;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import static local.load.EXERCISES_FILE;
import static local.load.MARKS_FILE;
import static local.load.exercises;
import static local.load.marks;

/**
 *
 * @author Minh
 */
public class save {
    static void saveData() {
        saveFile(EXERCISES_FILE, exercises);
        saveFile(MARKS_FILE, marks);
    }

    static void saveFile(String filename, ArrayList<String[]> data) {
        try {
            FileWriter writer = new FileWriter(filename);
            for (String[] fields : data) {
                writer.write(String.join(";", fields) + "\n");
            }

            writer.close();
        } catch (IOException e) {
            System.out.println("Error saving data to file " + filename);
            e.printStackTrace();
        }
    }
}
