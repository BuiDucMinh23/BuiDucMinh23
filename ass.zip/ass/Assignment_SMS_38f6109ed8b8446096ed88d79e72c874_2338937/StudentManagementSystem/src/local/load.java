package local;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import static local.save.saveFile;


/**
 *
 * @author Minh
 */
public class load {

    static final String STUDENTS_FILE = "C:\\JAVA\\students.txt";
    static final String SUBJECTS_FILE = "C:\\JAVA\\subjects.txt";
    static final String EXERCISES_FILE = "C:\\JAVA\\exercises.txt";
    static final String MARKS_FILE = "C:\\JAVA\\marks.txt";

    // Lists to store data from files
    static ArrayList<String[]> students = new ArrayList<>(6);
    static ArrayList<String[]> subjects = new ArrayList<>(6);
    static ArrayList<String[]> exercises = new ArrayList<>(6);
    static ArrayList<String[]> marks = new ArrayList<>(6);

    static void loadData() {
        loadFile(STUDENTS_FILE, students);
        loadFile(SUBJECTS_FILE, subjects);
        loadFile(EXERCISES_FILE, exercises);
        loadFile(MARKS_FILE, marks);
    }

    static void loadFile(String filename, ArrayList<String[]> data) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(filename));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split(";");
                data.add(fields);
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Error loading data from file " + filename);
            e.printStackTrace();
        }
    }

    

    

}
